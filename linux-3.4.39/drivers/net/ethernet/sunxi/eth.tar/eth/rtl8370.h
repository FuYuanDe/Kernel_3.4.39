#ifndef _RTL8370_H_
#define _RTL8370_H_

#define PORT0_MASK          0x001
#define PORT1_MASK          0x002
#define PORT8_MASK          0x100
#define PORT9_MASK          0x200

#endif
